package paraBankTesting;

import org.testng.Assert;

import bankPOM.BaseTest;
import bankPOM.DashboardPOM;
import bankPOM.HomepagePOM;
import bankPOM.RegistrationPagePOM;


public class AllpageTest extends BaseTest{
public void registrationID() {
	
    HomepagePOM homePage = new HomepagePOM(driver);
    homePage.clickRegister();
    
    RegistrationPagePOM regPage = new RegistrationPagePOM(driver);

    regPage.registerYourId(
        "Backiya",
        "Lakshmi",
        "Anna Nagar",
        "Madurai",
        "Tamil Nadu",
        "625001",
        "9876543210",
        "123456789",
        "backiya123",
        "password123",
        "password123"
    );
   
}

public void loginVerification() {

	HomepagePOM homePage = new HomepagePOM(driver);
	homePage.enterUsername("backiya123");
	homePage.enterPassword("password123");
	homePage.clickLogin();
	
	DashboardPOM dashboard = new DashboardPOM(driver);

	String welcomeText = dashboard.getCustomerName();
    Assert.assertTrue(welcomeText.contains("Accounts Overview"),
        "Login failed! Expected welcome message, got: " + welcomeText);
  
	dashboard.logout();
}

public void transferTheAmount() {

	HomepagePOM homePage = new HomepagePOM(driver);
	homePage.enterUsername("backiya123");
	homePage.enterPassword("password123");
	homePage.clickLogin();
	
	DashboardPOM dashboard = new DashboardPOM(driver);
 dashboard.getCustomerName();
	dashboard.transferFunds("100");

	 String transferMessage = dashboard.getTransferDetails();

	    Assert.assertTrue(
	        transferMessage.contains("Transfer"),
	        "Transfer failed! Actual message: " + transferMessage
	    );


	dashboard.logout();
}


public void loanRequest() {

	HomepagePOM homePage = new HomepagePOM(driver);
	homePage.enterUsername("backiya123");
	homePage.enterPassword("password123");
	homePage.clickLogin();
	
	DashboardPOM dashboard = new DashboardPOM(driver);
	dashboard.loanRequest("200", "140");

	String loanResult = dashboard.getLoanDetails().trim();
	Assert.assertTrue(
		    loanResult.equals("Loan Request Processed") || loanResult.equals("Denied"),
		    "Unexpected loan result! Actual: " + loanResult
		);




	dashboard.logout();
}


}
