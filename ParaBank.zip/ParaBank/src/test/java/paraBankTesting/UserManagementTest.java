package paraBankTesting;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class UserManagementTest extends AllpageTest {
	 @BeforeClass
	    public void setup() {
	        System.out.println("Starting User Management Test Suite");
	    }

	    @Test(priority = 1)
	    public void runRegistrationoftheID() {
	    	registrationID();
	        System.out.println("Registration Done");
	    }
	    
	    @Test(priority = 2)
	    public void runLoginVerification() {
	    	loginVerification();
	        System.out.println("Log in verification Done");
	    }
	    @Test(priority = 3)
	    public void runVerifyTransferFunds() {
	   transferTheAmount();
	        System.out.println("Transfer Funds verification Done");
	    }
	    
	    @Test(priority = 4)
	    public void runVerifyLoanRequest() {
	    	loanRequest();
	        System.out.println("Loan Request verification Done");
	    }	    
	    
	 	    
}
