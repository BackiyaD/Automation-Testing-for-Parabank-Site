package bankPOM;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

public class DashboardPOM {
	 WebDriver driver;

	    public DashboardPOM(WebDriver driver) {
	        this.driver = driver;
	        PageFactory.initElements(driver, this);
	    }
	    
	@FindBy(xpath = "//h1[@class='title']")
	WebElement welcomePreview;
	
	@FindBy(xpath = "//a[text()=\"Transfer Funds\"]")
	WebElement transferFunds;
	
	@FindBy(xpath = "//a[text()=\"Request Loan\"]")
	WebElement reqLoan;
	
	@FindBy(xpath = "//input[@id='amount']")
	WebElement amount;
	
	@FindBy(id = "fromAccountId")
	WebElement fromAccountDropdown;

	@FindBy(id = "toAccountId")
	WebElement toAccountDropdown;
	
	@FindBy(xpath = "//input[@class='button']")
	WebElement transferButton;
	
	@FindBy(xpath = "//a[text()=\"Log Out\"]")
	WebElement logout;
	
	@FindBy(xpath = "//h1[@class='title']")
	WebElement transferDetails;
	
	@FindBy(xpath = "//input[@id='amount']")
	WebElement loanAmount;
	
	@FindBy(xpath = "//input[@id='downPayment']")
	WebElement downPay;
	
	@FindBy(id = "fromAccountId")
	WebElement loanfromAccountDropdown;
	
	@FindBy(xpath = "//td[@colspan='2']/input[@value='Apply Now']")
	WebElement applyNowButton;
	
	@FindBy(xpath = "//h1[@class='title']")
	WebElement loanDetails;
	
	
	public String getCustomerName() {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
	    WebElement nameElement = wait.until(
	        ExpectedConditions.visibilityOf(welcomePreview)
	    );
	    return nameElement.getText();

	}
	

	    public void transferFunds(String amt) {
	     	transferFunds.click();
	     	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
	        wait.until(ExpectedConditions.urlContains("transfer.htm"));
	        amount.sendKeys(amt);
	       

	        Select fromSelect = new Select(fromAccountDropdown);
	        Select toSelect = new Select(toAccountDropdown);

	       
	        fromSelect.selectByIndex(0);
	        toSelect.selectByIndex(0);
			 transferButton.click();
		
		
	    }
	    
		public String getTransferDetails() {
			  WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
			    wait.until(ExpectedConditions.visibilityOf(transferDetails));
			    return transferDetails.getText();

		}
		
		 public void loanRequest(String loanAmt, String downPayment) {
		   
		     	reqLoan.click();		
		        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		        wait.until(ExpectedConditions.urlContains("requestloan.htm"));
			    loanAmount.sendKeys(loanAmt);
			    downPay.sendKeys(downPayment);
				   
			    applyNowButton.click();
			 
		    }
		 
		 public String getLoanDetails() {
			   WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
			    WebElement pageDetails = wait.until(
			        ExpectedConditions.visibilityOfElementLocated(
			            By.xpath("//*[contains(text(),'Loan Request Processed') or contains(text(),'Denied')]")
			        )
			    );
			    return pageDetails.getText().trim();

			}
		 
		
public void logout() {
	logout.click();
}
	}

