package bankPOM;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

public class RegistrationPagePOM {
	WebDriver driver;

    public RegistrationPagePOM(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }
    @FindBy(xpath = "//input[@name='customer.firstName']")
    WebElement firstname;

    @FindBy(xpath = "//input[@name='customer.lastName']")
    WebElement lastname;
    
    @FindBy(xpath = "//input[@name='customer.address.street']")
    WebElement address;

    @FindBy(xpath = "//input[@name='customer.address.city']")
    WebElement city;
    
    @FindBy(xpath = "//input[@name='customer.address.state']")
    WebElement state;

    @FindBy(xpath = "//input[@name='customer.address.zipCode']")
    WebElement zipcode;
    
    @FindBy(xpath = "//input[@name='customer.phoneNumber']")
    WebElement phone;
    
    @FindBy(xpath = "//input[@name='customer.ssn']")
    WebElement ssn;

    @FindBy(xpath = "//input[@name='customer.username']")
    WebElement regUsername;
    
    @FindBy(xpath = "//input[@name='customer.password']")
    WebElement regPassword;
    
    @FindBy(xpath = "//input[@name='repeatedPassword']")
    WebElement confirmPassword;
    
    @FindBy(xpath = "//input[@value='Register']")
    WebElement regButton;
    
	@FindBy(xpath = "//h1[@class='title']")
    WebElement successMsg;
    
    public void registerYourId(String fName, String lName, String addr, String cityName,
            String stateName, String zip, String phoneNo,
            String ssnNo, String userName, String pwd, String confirmPwd) {

firstname.sendKeys(fName);
lastname.sendKeys(lName);
address.sendKeys(addr);
city.sendKeys(cityName);
state.sendKeys(stateName);
zipcode.sendKeys(zip);
phone.sendKeys(phoneNo);
ssn.sendKeys(ssnNo);
regUsername.sendKeys(userName);
regPassword.sendKeys(pwd);
confirmPassword.sendKeys(confirmPwd);
WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
wait.until(ExpectedConditions.elementToBeClickable(regButton)).click();
Assert.assertTrue(successMsg.getText().contains(userName));


}
    
}
