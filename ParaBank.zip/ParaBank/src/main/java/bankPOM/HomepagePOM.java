package bankPOM;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class HomepagePOM {
	 WebDriver driver;

	    public HomepagePOM(WebDriver driver) {
	        this.driver = driver;
	        PageFactory.initElements(driver, this);
	    }

	    @FindBy(xpath = "//input[@name='username']")
	    WebElement username;

	    @FindBy(xpath = "//input[@name='password']")
	    WebElement password;

	    @FindBy(xpath = "//input[@class='button']")
	    WebElement login;

	    @FindBy(xpath = "//a[text()='Forgot login info?']")
	    WebElement forgotInfo;

	    @FindBy(xpath = "//a[text()='Register']")
	    WebElement register;

	    public void enterUsername(String uname) {
	        username.sendKeys(uname);
	    }

	    public void enterPassword(String pwd) {
	        password.sendKeys(pwd);
	    }

	    public void clickLogin() {
	        login.click();
	        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
	        wait.until(ExpectedConditions.visibilityOfElementLocated(
	            By.xpath("//h1[@class='title']")));
	    }

	    public void clickRegister() {
	        register.click();
	    }

	    public void clickForgotInfo() {
	        forgotInfo.click();
	    }
}
